# Tomar's Infra - Gwalior's Premium Real Estate

A premium, responsive HTML/CSS website template for **Tomar's Infra**, a real estate company led by CEO **Manvendra Singh Tomar** and based in Gwalior, Madhya Pradesh.

## Setup Instructions

1.  **Project Root:** Create a folder named `tomars-infra`.
2.  **Files:** Inside this folder, save each of the code blocks provided above into their respective filenames (`index.html`, `about.html`, ..., `style.css`, etc.).
3.  **Image Folder:** Create an `images` folder inside `tomars-infra`.

## Adding Real Images (Crucial for a Premium Look)

You need to place the following images in the `images` folder for the site to display correctly. Ensure you use high-quality, professional photographs to maintain the premium feel.

*   **`images/hero.jpg`**: A stunning, high-resolution photo of a luxury home exterior or a prominent view of the Gwalior skyline. *Used on `index.html` (Hero section background).*
*   **`images/ceo.jpg`**: A professional headshot of CEO **Manvendra Singh Tomar**. *Used on `index.html` (CEO statement) and `about.html` (Profile).*
*   **`images/prop1.jpg`**: A high-quality photo of a luxury villa (e.g., Royal Heritage Villa). *Used on `index.html`.*
*   **`images/prop2.jpg`**: A photo of a modern apartment building. *Used on `index.html`.*
*   **`images/prop3.jpg`**: A photo of a modern suburban home. *Used on `index.html`.*

*(You may need additional images if you plan to populate the other pages with more visual content.)*

## Key Premium Features

*   **Premium Color Palette:** Uses deep charcoal (`#1c1c1c`) for the base, sophisticated bronze/gold (`#a87f4c`) for accents, and rich blue (`#0d4a7a`) for primary actions.
*   **Elegant Typography:** Features 'Playfair Display' for classic headings and 'Montserrat' for clean, modern body text.
*   **Responsive Layout:** The grid structure for properties and services adapts automatically to various screen sizes.
*   **Distinct Hero Section:** Focuses on the company vision and explicitly mentions the CEO and location.
*   **CEO's Personal Touch:** Dedicates a special section on the home page for a message from Manvendra Singh Tomar, establishing trust.
*   **Styled Form Elements:** Uses modern CSS for cleaner forms on Login, Register, and Payment pages.
*   **Subtle Animations:** Features smooth hover transitions on cards, buttons, and navigation links.

## Customization

*   **Logo Text:** The `<a href="index.html" class="logo">` tag contains the company name. You can wrap it in a `<span>` to add a small tagline as I have done.
*   **Property Details:** The pricing and specifications in `index.html` are placeholders. Update them with actual data.
*   **Services Cop:** The text in `services.html` provides a good base. Refine it based on your exact offerings.
*   **Legal Text:** The information in `legal.html` is a template. Please consult a legal professional for real-world terms and privacy policies.